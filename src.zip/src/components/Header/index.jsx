import { Container, Profile, Logout } from './styles';
import { RiShutDownLine } from 'react-icons/ri';

export function Header() {
  return (
    <Container>
      <Profile>
        <img
          src="https://github.com/rafaelafpro.png"
          alt="Foto do Usuário" />

        <div>
          <span>Bem-vindo,</span>
          <strong>Rafael Andrade</strong>
        </div>
      </Profile>

      <Logout>
        <RiShutDownLine></RiShutDownLine>
      </Logout>
    </Container>
  )
}
