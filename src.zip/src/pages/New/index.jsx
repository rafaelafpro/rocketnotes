import { Container, Form } from './styles'
import { Header } from '../../components/Header';
import { Input } from '../../components/Input'
import { Textarea } from '../../components/Textarea'
import { NoteItem } from '../../components/NoteItem'
import { Section } from '../../components/Section'

export function New() {
  return (
    <Container>
      <Header />

      <main>
        <Form>
          <header>
            <h1>Criar Nota</h1>
            <a href="/">Voltar</a>
          </header>

          <Input placeholder="Titulo" />
          <Textarea placeholder="Observações" />

          <Section title="Link Úteis">
            <NoteItem
              value="https://rocketseat.com.br"
            />
            <NoteItem
              isNew="true"
              placeholder="Novo Link"
            />
          </Section>

          <Section title="Marcadores">
            <div className='tags'>

              <NoteItem
                value="js"
              />
              <NoteItem
                value="react Native"
              />
              <NoteItem
                value="react"
              />
              <NoteItem
                isNew="true"
                placeholder="Nova Tag"
              />
            </div>
          </Section>
        </Form>
      </main>
    </Container>
  )
}